package com.javaclimb.drug.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.javaclimb.drug.entity.Returngoods;

/**
 * 收到退货的增删改查Mapper
 */
public interface ReturngoodsMapper extends BaseMapper<Returngoods> {
}
